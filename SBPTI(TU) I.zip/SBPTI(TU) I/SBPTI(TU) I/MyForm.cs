﻿//MyForm.cs

using System;
using System.Windows.Forms;

namespace SBPTI_TU__I
{
    public class MyForm : Form
    {
        private MenuStrip _menuStrip;
        private TextBox _outField;
        private Button _buttonStart;
        private Label _label;
        private string _info = "Приветствуем вас в программе Васянина Ильи Александровича,\nстудента СПБГТИ(ТУ) группы 444,\nвыполнившего 1 лабораторную работу по дисциплине \"Разработка программных систем\"!\nЭто лучшая программа по машине Тьюринга!!!!";
        public MyForm()
        {
            this.MinimumSize = this.MaximumSize = new Size(550, 250);

            this.Text = "Машина Тьюринга";

            _menuStrip = new MenuStrip();
            ToolStripMenuItem info = new ToolStripMenuItem("Справка");

            info.Click += (sender, e) => MessageBox.Show(_info, "Справка");

            _label = new Label();
            _label.Text = "Введите строку, состоящую только из латинсиких символов \"a\" и \"b\".";
            _label.AutoSize = true;
            _label.Location = new Point(20, 50);

            _outField = new TextBox();
            _outField.Size = new Size(400, 20);
            _outField.Location = new Point(20, 90);

            _buttonStart = new Button();
            _buttonStart.Text = "Запуск";
            _buttonStart.Size = new Size(100, 50);
            _buttonStart.Location = new Point(20, 130);
            _buttonStart.Click += (sender, e) =>
            {
                if (TouringMachine.CheckSymbols(_outField.Text)) MessageBox.Show(TouringMachine.Alghoritm(_outField.Text), "Вывод");
                else if(_outField.Text.Length == 0) MessageBox.Show("Ничего не введено!", "Ошибка ввода");
                else MessageBox.Show("В строке есть лишние символы!", "Ошибка ввода");
            };

            _menuStrip.Items.Add(info);
            this.Controls.Add(_menuStrip);
            this.Controls.Add(_label);
            this.Controls.Add(_outField);
            this.Controls.Add(_buttonStart);
        }
    }
}
