﻿//TouringMachine.cs

using System;

namespace SBPTI_TU__I
{
    public class TouringMachine
    {
        public static bool CheckSymbols(string str)
        {
            Type type = typeof(TouringMachine);
            if(str.Length == 0) return false;

            foreach(char c in str)
            {
                if(!(c == 'a' || c == 'b')) return false;
            }

            return true;
        }

        public static string Alghoritm(string str)
        {
            char[] String = (str + " ").ToCharArray();

            int i = 0;
            int move = 1;
            bool even = false;

            if(String[i] == 'b') { String[i] = 'N'; }
            else { String[i] = 'Y'; even = true; }
            i++;

            if (i < String.Length)
            { 
                while(i < String.Length)
                {
                    switch(String[i])
                    {
                        case 'a':
                            break;
                        case 'b':
                            String[i] = 'a';
                            even = !even;
                            move = -1;
                            break;
                        case 'Y':
                            if (!even) { String[i] = 'N'; }
                            move = 1;
                            break;
                        case 'N':
                            if (even) { String[i] = 'Y'; }
                            move = 1;
                            break;
                    }
                    i += move;
                }
            }
            else
            {
                while (String[i]!='N' || String[i] != 'Y')
                {
                    String[i] = ' ';
                    i--;
                }
            }

            return Convert.ToString(String[0]);
        }
    
    
    }
}
