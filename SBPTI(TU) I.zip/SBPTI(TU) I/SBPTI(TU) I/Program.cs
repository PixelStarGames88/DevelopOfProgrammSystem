﻿//Programm.cs

namespace SBPTI_TU__I
{
    internal static class Program
    {

        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new MyForm());
        }
    }
}